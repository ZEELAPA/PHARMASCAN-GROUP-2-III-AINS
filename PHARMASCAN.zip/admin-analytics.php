<?php

include('auth.php');
require_admin();
include('sqlconnect.php');

// Basic Session Check
if (!isset($_SESSION['AccountID'])) {
    header('Location: login.php');
    exit();
}

// =============================================================
//  BACKEND LOGIC: PROCESS DATA FOR CHARTS
// =============================================================

// --- 1. LEAVE BREAKDOWN (Pie Chart) ---
// Logic: Count rows based on 'Reason' keywords.
$sqlLeave = "SELECT 
    SUM(CASE WHEN Reason LIKE '%Sick%' THEN 1 ELSE 0 END) as SickCount,
    SUM(CASE WHEN Reason LIKE '%Vacation%' THEN 1 ELSE 0 END) as VacationCount
    FROM tblleaveform 
    WHERE LeaveStatus = 'Approved'"; 

$resultLeave = $conn->query($sqlLeave);
$leaveData = $resultLeave->fetch_assoc();
$sickCount = $leaveData['SickCount'] ?? 0;
$vacationCount = $leaveData['VacationCount'] ?? 0;

// --- 2. ABSENCES BY DAY (Bar Chart + Insight) ---
// Logic: (Total Active Employees) - (Average Attendance per Day)

// A. Get Total Active Employees
$sqlTotalEmp = "SELECT COUNT(*) as Total FROM tblemployees WHERE EmploymentStatus = 'Active'";
$resTotalEmp = $conn->query($sqlTotalEmp);
$totalEmployees = $resTotalEmp->fetch_assoc()['Total'];

// B. Get Attendance Stats (Last 3 Months)
$sqlAtt = "SELECT 
    DAYNAME(AttendanceDate) as DayName, 
    COUNT(*) as TotalPresent, 
    COUNT(DISTINCT AttendanceDate) as UniqueDates
    FROM tblattendance 
    JOIN tblaccounts ON tblattendance.AccountID = tblaccounts.AccountID
    JOIN tblemployees ON tblaccounts.EmployeeID = tblemployees.EmployeeID
    WHERE tblattendance.AttendanceDate >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
    AND tblemployees.EmploymentStatus = 'Active'
    GROUP BY DayName";

$resultAtt = $conn->query($sqlAtt);

// Map DB results to an associative array
$attendanceMap = [];
while($row = $resultAtt->fetch_assoc()) {
    $avgPresent = $row['TotalPresent'] / $row['UniqueDates'];
    $attendanceMap[$row['DayName']] = $avgPresent;
}

// Calculate Absences for Mon-Fri
$daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$absenceCounts = [];
$highestDay = '';
$highestCount = -1;

foreach($daysOfWeek as $day) {
    $avgPresent = isset($attendanceMap[$day]) ? $attendanceMap[$day] : 0;
    // Absence = Total Employees - Average Present
    $absent = max(0, round($totalEmployees - $avgPresent));
    $absenceCounts[] = $absent;

    if($absent > $highestCount) {
        $highestCount = $absent;
        $highestDay = $day;
    }
}

// Generate Insight Text
$avgAbsence = array_sum($absenceCounts) / count($absenceCounts);
$pctDiff = ($avgAbsence > 0) ? round((($highestCount - $avgAbsence) / $avgAbsence) * 100) : 0;
$insightText = ($highestCount > 0) 
    ? "<strong>{$highestDay}</strong> shows <strong>{$pctDiff}% higher</strong> absences than the weekly average."
    : "No significant absence patterns detected.";

// --- 3. LEAVE FORECAST (Line Chart) ---
// Logic: Historical Data + Simple Moving Average (SMA) of last 3 months

// A. Get History (Last 6 Months)
$sqlHistory = "SELECT 
    DATE_FORMAT(ScheduledLeave, '%M') as MonthName, 
    COUNT(*) as Count 
    FROM tblleaveform 
    WHERE LeaveStatus = 'Approved' 
    AND ScheduledLeave >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(ScheduledLeave, '%Y-%m') 
    ORDER BY ScheduledLeave ASC";

$resultHistory = $conn->query($sqlHistory);
$historyLabels = [];
$historyData = [];

while($row = $resultHistory->fetch_assoc()) {
    $historyLabels[] = $row['MonthName'];
    $historyData[] = $row['Count'];
}

// B. Calculate Prediction
$forecastVal = 0;
$cnt = count($historyData);
if ($cnt >= 3) {
    $sum = $historyData[$cnt-1] + $historyData[$cnt-2] + $historyData[$cnt-3];
    $forecastVal = round($sum / 3);
} elseif ($cnt > 0) {
    $forecastVal = round(array_sum($historyData) / $cnt);
}

// C. Prepare Chart Arrays
// Labels: History + Next Month
$nextMonth = date('M', strtotime('+1 month'));
$forecastLabels = array_merge($historyLabels, [$nextMonth]);

// Solid Line (History): Pad end with null
$solidData = $historyData;
$solidData[] = null;

// Dashed Line (Forecast): Pad beginning with nulls, connect to last history point
$dashedData = array_fill(0, count($historyData)-1, null);
if($cnt > 0) { $dashedData[] = end($historyData); } // Connection point
$dashedData[] = $forecastVal; // Prediction point

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/admin-analytics.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="styles/global.css?v=<?php echo time(); ?>">
    <title>Admin Analytics | PharmaScan</title>

    <link rel="icon" type="image/png" href="images/PharmaScanLogo.png">
    
    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- INJECT PHP DATA INTO JS -->
    <script>
        const dashboardData = {
            pie: {
                sick: <?php echo $sickCount; ?>,
                vacation: <?php echo $vacationCount; ?>
            },
            bar: {
                labels: <?php echo json_encode($daysOfWeek); ?>,
                data: <?php echo json_encode($absenceCounts); ?>
            },
            line: {
                labels: <?php echo json_encode($forecastLabels); ?>,
                history: <?php echo json_encode($solidData); ?>,
                forecast: <?php echo json_encode($dashedData); ?>
            }
        };
    </script>

    <script defer src="scripts/global.js?v=<?php echo time(); ?>"></script>
    <script defer src="scripts/admin-analytics.js?v=<?php echo time(); ?>"></script>
</head>
<body>
    <div class="app-container">
        
        <?php include('toast-message.php'); ?>
        <?php include('admin-sidebar.php'); ?>

        <main class="main-container">
            <div class="main-panel">
                
                <div class="header-section">
                    <div class="main-title">
                        <h3>Analytics</h3>
                        <p>Data-driven Decisions at your Screen</p>
                    </div>
                </div>

                <div class="panels-container">
                    <!-- TOP SECTION: 2 Panels -->
                    <div class="top-panels">
                        
                        <!-- Top Panel 1: Breakdown -->
                        <div class="content-panel top-left-panel">
                            <div class="panel-header">
                                <h4>Breakdown of Leave Types</h4>
                            </div>
                            <div class="panel-body">
                                <p style="font-size: 0.8rem; color: #888; margin-bottom:10px;">Distribution of leave categories</p>
                                <div class="chart-container">
                                    <canvas id="leavePieChart"></canvas>
                                </div>
                            </div>
                        </div>

                        <!-- Top Panel 2: Absences -->
                        <div class="content-panel top-right-panel">
                            <div class="panel-header">
                                <h4>Absences by Day of Week</h4>
                            </div>
                            <div class="panel-body">
                                <p style="font-size: 0.8rem; color: #888; margin-bottom:10px;">Pattern analysis for potential morale indicators (Weekly Absences Average)</p>
                                <div class="chart-container" style="max-height: 150px;">
                                    <canvas id="absenceBarChart"></canvas>
                                </div>
                                <!-- Dynamic Insight -->
                                <div class="insight-box">
                                    <i class="fa fa-info-circle"></i>
                                    <span><?php echo $insightText; ?></span>
                                </div>
                            </div>
                        </div>

                    </div>
    
                    <!-- BOTTOM SECTION: Forecast -->
                    <div class="bottom-panels">
                        <div class="content-panel bottom-full-panel">
                            <div class="panel-header">
                                <h4>Leave Forecasting - Time Series Analysis</h4>
                            </div>
                            <div class="panel-body"> 
                                <p style="font-size: 0.8rem; color: #888; margin-bottom:10px;">Historical data with predictive forecast using Simple Moving Average</p>
                                <div class="chart-container" style="height: 225px;">
                                    <canvas id="forecastLineChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
</body>
</html>